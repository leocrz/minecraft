using System.Web;
using MinecraftManager.Models;
using MinecraftManager.Services;
using MinecraftManager.Utils;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Minicraft

{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void buttonBuscar_Click(object sender, EventArgs e)
        {
            int id = int.Parse(textBoxID.Text);


            JugadorService jugadorService = new JugadorService(new DatabaseManager());
            Jugador jugador = jugadorService.ObtenerPorId(id);
            if (jugador != null)
            {

                textBoxNombre.Text = jugador.Nombre;
                textBoxNivel.Text = jugador.Nivel.ToString();
                textBoxFechaCreacion.Text = jugador.FechaCreacion.ToShortDateString();
            }
            else
            {

                textBoxNombre.Text = "Jugador no encontrado.";
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void buttonCrear_Click(object sender, EventArgs e)
        {
            Jugador jugador = new Jugador
            {
                Nombre = textBoxNombre.Text,
                Nivel = int.Parse(textBoxNivel.Text) // �Aseg�rate de que sea un n�mero v�lido!
            };

            try
            {
                var servicioJugador = new JugadorService(new DatabaseManager());
                servicioJugador.Crear(jugador);

                MessageBox.Show($"�Jugador creado exitosamente con ID {jugador.Id}!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al crear el jugador: {ex.Message}");
            }
        }

        private void buttonEliminar_Click(object sender, EventArgs e)
        {
            try
            {

                int id = int.Parse(textBoxID.Text);
                JugadorService servicioJugador = new JugadorService(new DatabaseManager());
                servicioJugador.Eliminar(id);

                MessageBox.Show("Operaci�n de eliminaci�n finalizada.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar el jugador: {ex.Message}");
            }
        }

        private void buttonActualizar_Click(object sender, EventArgs e)
        {
            try
            {
                int id = int.Parse(textBoxID.Text);
                string nombre = textBoxNombre.Text;
                int nivel = int.Parse(textBoxNivel.Text);

                Jugador jugador = new Jugador
                {
                    Id = id,
                    Nombre = nombre,
                    Nivel = nivel
                };

                JugadorService servicioJugador = new JugadorService(new DatabaseManager());
                servicioJugador.Actualizar(jugador);

                MessageBox.Show("Operaci�n de actualizaci�n finalizada.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al actualizar el jugador: {ex.Message}");
            }
        }

        private void comboBoxTipoBloque_SelectedIndexChanged(object sender, EventArgs e)
        {
            InventarioService inve = new InventarioService(new DatabaseManager(), new JugadorService(new DatabaseManager()), new BloqueService(new DatabaseManager()));
            BloqueService bloque = new BloqueService(new DatabaseManager());
            string? opcion = comboBoxTipoBloque.SelectedItem?.ToString();


            if (opcion == "Todo")
            {
                List<Inventario> inventarios = inve.ObtenerTodos();
               
                
                List<Bloque> bloques = bloque.ObtenerTodos();

                
                dataGridView.DataSource = bloques;
            }
            else if (opcion == "Madera")
            {

                List<Bloque> bloques = bloque.BuscarPorTipo("Madera");
                dataGridView.DataSource = bloques;
            }
            else if (opcion == "Mineral")
            {
                List<Bloque> bloques = bloque.BuscarPorTipo("Mineral");
                dataGridView.DataSource = bloques;
            }
            else if (opcion == "�pico")
            {
                
                List<Bloque> bloques = bloque.BuscarPorRareza("�pico");
                dataGridView.DataSource = bloques;
            }
            else if (opcion == "Com�n")
            {
                List<Bloque> bloques = bloque.BuscarPorRareza("Com�n");
                dataGridView.DataSource = bloques;

            }
            else
            {
                List<Bloque> bloques = bloque.BuscarPorRareza("Raro");
                dataGridView.DataSource = bloques;
            }
        }

        private void dataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}



