﻿namespace Minicraft
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            buttonCrear = new Button();
            buttonBuscar = new Button();
            textBoxID = new TextBox();
            textBoxNombre = new TextBox();
            label3 = new Label();
            label4 = new Label();
            textBoxNivel = new TextBox();
            textBoxFechaCreacion = new TextBox();
            buttonEliminar = new Button();
            buttonActualizar = new Button();
            dataGridView = new DataGridView();
            comboBoxTipoBloque = new ComboBox();
            label5 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(50, 118);
            label1.Name = "label1";
            label1.Size = new Size(74, 20);
            label1.TabIndex = 0;
            label1.Text = "NOMBRE ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(50, 60);
            label2.Name = "label2";
            label2.Size = new Size(24, 20);
            label2.TabIndex = 1;
            label2.Text = "ID";
            // 
            // buttonCrear
            // 
            buttonCrear.Location = new Point(550, 58);
            buttonCrear.Name = "buttonCrear";
            buttonCrear.Size = new Size(94, 29);
            buttonCrear.TabIndex = 2;
            buttonCrear.Text = "CREAR";
            buttonCrear.UseVisualStyleBackColor = true;
            buttonCrear.Click += buttonCrear_Click;
            // 
            // buttonBuscar
            // 
            buttonBuscar.Location = new Point(388, 60);
            buttonBuscar.Name = "buttonBuscar";
            buttonBuscar.Size = new Size(94, 29);
            buttonBuscar.TabIndex = 3;
            buttonBuscar.Text = "BUSCAR";
            buttonBuscar.UseVisualStyleBackColor = true;
            buttonBuscar.Click += buttonBuscar_Click;
            // 
            // textBoxID
            // 
            textBoxID.Location = new Point(201, 60);
            textBoxID.Name = "textBoxID";
            textBoxID.Size = new Size(125, 27);
            textBoxID.TabIndex = 4;
            // 
            // textBoxNombre
            // 
            textBoxNombre.Location = new Point(201, 111);
            textBoxNombre.Name = "textBoxNombre";
            textBoxNombre.Size = new Size(125, 27);
            textBoxNombre.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(50, 184);
            label3.Name = "label3";
            label3.Size = new Size(48, 20);
            label3.TabIndex = 6;
            label3.Text = "NIVEL";
            label3.Click += label3_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(50, 246);
            label4.Name = "label4";
            label4.Size = new Size(152, 20);
            label4.TabIndex = 7;
            label4.Text = "FECHA DE CREACION";
            // 
            // textBoxNivel
            // 
            textBoxNivel.Location = new Point(208, 177);
            textBoxNivel.Name = "textBoxNivel";
            textBoxNivel.Size = new Size(125, 27);
            textBoxNivel.TabIndex = 8;
            // 
            // textBoxFechaCreacion
            // 
            textBoxFechaCreacion.Location = new Point(208, 239);
            textBoxFechaCreacion.Name = "textBoxFechaCreacion";
            textBoxFechaCreacion.Size = new Size(125, 27);
            textBoxFechaCreacion.TabIndex = 9;
            // 
            // buttonEliminar
            // 
            buttonEliminar.Location = new Point(388, 128);
            buttonEliminar.Name = "buttonEliminar";
            buttonEliminar.Size = new Size(94, 29);
            buttonEliminar.TabIndex = 10;
            buttonEliminar.Text = "ELIMINAR";
            buttonEliminar.UseVisualStyleBackColor = true;
            buttonEliminar.Click += buttonEliminar_Click;
            // 
            // buttonActualizar
            // 
            buttonActualizar.Location = new Point(550, 128);
            buttonActualizar.Name = "buttonActualizar";
            buttonActualizar.Size = new Size(94, 29);
            buttonActualizar.TabIndex = 11;
            buttonActualizar.Text = "ACTUALIZAR";
            buttonActualizar.UseVisualStyleBackColor = true;
            buttonActualizar.Click += buttonActualizar_Click;
            // 
            // dataGridView
            // 
            dataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView.Location = new Point(50, 347);
            dataGridView.Name = "dataGridView";
            dataGridView.RowHeadersWidth = 51;
            dataGridView.Size = new Size(565, 188);
            dataGridView.TabIndex = 12;
            dataGridView.CellContentClick += dataGridView_CellContentClick;
            // 
            // comboBoxTipoBloque
            // 
            comboBoxTipoBloque.FormattingEnabled = true;
            comboBoxTipoBloque.Items.AddRange(new object[] { "Todo", "Madera", "Mineral", "Épico", "Común", "Raro" });
            comboBoxTipoBloque.Location = new Point(245, 294);
            comboBoxTipoBloque.Name = "comboBoxTipoBloque";
            comboBoxTipoBloque.Size = new Size(251, 28);
            comboBoxTipoBloque.TabIndex = 13;
            comboBoxTipoBloque.SelectedIndexChanged += comboBoxTipoBloque_SelectedIndexChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(43, 297);
            label5.Name = "label5";
            label5.Size = new Size(196, 20);
            label5.TabIndex = 14;
            label5.Text = "BLOQUE POR TIPO/RAREZA ";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 547);
            Controls.Add(label5);
            Controls.Add(comboBoxTipoBloque);
            Controls.Add(dataGridView);
            Controls.Add(buttonActualizar);
            Controls.Add(buttonEliminar);
            Controls.Add(textBoxFechaCreacion);
            Controls.Add(textBoxNivel);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(textBoxNombre);
            Controls.Add(textBoxID);
            Controls.Add(buttonBuscar);
            Controls.Add(buttonCrear);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dataGridView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Button buttonCrear;
        private Button buttonBuscar;
        private TextBox textBoxID;
        private TextBox textBoxNombre;
        private Label label3;
        private Label label4;
        private TextBox textBoxNivel;
        private TextBox textBoxFechaCreacion;
        private Button buttonEliminar;
        private Button buttonActualizar;
        private DataGridView dataGridView;
        private ComboBox comboBoxTipoBloque;
        private Label label5;
    }
}
